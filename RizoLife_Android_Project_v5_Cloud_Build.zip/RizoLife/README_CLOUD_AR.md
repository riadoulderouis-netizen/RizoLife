# Rizo Life — بناء APK من الهاتف

هذا المشروع يحتوي على Workflow جاهز لـ GitHub Actions لبناء APK تجريبي.

## الطريقة من الهاتف
1. أنشئ مستودعًا جديدًا على GitHub.
2. ارفع محتويات مجلد `RizoLife` إلى المستودع (وليس ملف ZIP نفسه).
3. افتح تبويب **Actions**.
4. اختر **Build Rizo Life APK**.
5. شغّل Workflow يدويًا إذا لم يبدأ تلقائيًا.
6. بعد نجاح البناء، افتح نتيجة التشغيل ثم قسم **Artifacts**.
7. نزّل `RizoLife-debug-apk.zip`، فك الضغط، وثبّت `app-debug.apk` على هاتف Android.

## ملاحظات
- هذا APK تجريبي Debug وليس نسخة Play Store.
- لا توجد مفاتيح API داخل المشروع.
- مفاتيح TMDB وRAWG وGemini تدخل من داخل التطبيق وتُحفظ محليًا على الجهاز.
