package com.rizolife.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

// Rizo Life v4 — local personal organizer + free metadata/AI enrichment.
data class Item(val title:String, val detail:String="", val done:Boolean=false)
data class Media(
    val title:String,
    val type:String,
    val rating:Int,
    val note:String="",
    val posterUrl:String="",
    val year:String="",
    val genres:String="",
    val description:String="",
    val aiSummary:String=""
)

data class EnrichedMedia(
    val posterUrl:String="", val year:String="", val genres:String="",
    val description:String="", val aiSummary:String=""
)

class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RizoLifeApp(applicationContext) }
    }
}

class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("rizo_life_data", Context.MODE_PRIVATE)
    fun load(key:String): List<Item> {
        val arr=JSONArray(prefs.getString(key,"[]") ?: "[]")
        return List(arr.length()){i-> val o=arr.getJSONObject(i); Item(o.optString("title"),o.optString("detail"),o.optBoolean("done")) }
    }
    fun save(key:String,items:List<Item>){
        val arr=JSONArray(); items.forEach{arr.put(JSONObject().apply{put("title",it.title);put("detail",it.detail);put("done",it.done)})}
        prefs.edit().putString(key,arr.toString()).apply()
    }
    fun loadMedia(key:String="media"):List<Media>{
        val arr=JSONArray(prefs.getString(key,"[]") ?: "[]")
        return List(arr.length()){i->val o=arr.getJSONObject(i);Media(
            o.optString("title"),o.optString("type"),o.optInt("rating"),o.optString("note"),
            o.optString("posterUrl"),o.optString("year"),o.optString("genres"),o.optString("description"),o.optString("aiSummary"))}
    }
    fun saveMedia(items:List<Media>){
        val arr=JSONArray();items.forEach{m->arr.put(JSONObject().apply{
            put("title",m.title);put("type",m.type);put("rating",m.rating);put("note",m.note);put("posterUrl",m.posterUrl)
            put("year",m.year);put("genres",m.genres);put("description",m.description);put("aiSummary",m.aiSummary)
        })};prefs.edit().putString("media",arr.toString()).apply()
    }
    fun get(key:String)=prefs.getString(key,"") ?: ""
    fun set(key:String,value:String)=prefs.edit().putString(key,value).apply()
}

@Composable
fun RizoLifeApp(context:Context){
    var tab by remember{mutableIntStateOf(0)}
    val names=listOf("الرئيسية","ذكرياتي","أهدافي","مهامي","ملاحظاتي","ترفيهي")
    val store=remember{LocalStore(context)}
    Scaffold(bottomBar={NavigationBar{names.forEachIndexed{i,n->NavigationBarItem(tab==i,{tab=i},{Text(listOf("⌂","♥","★","✓","✎","🎬")[i])},{Text(n)})}}}){p->
        Box(Modifier.padding(p).fillMaxSize()){when(tab){
            0->Home(store);1->PersistentSection("🧠 ذكرياتي","الأحداث واللحظات المهمة.","memories",store)
            2->PersistentSection("🎯 أهدافي","أهدافك وخطوات تقدمك.","goals",store);3->PersistentTasks(store)
            4->PersistentSection("📝 ملاحظاتي","أفكارك وملاحظاتك.","notes",store);5->MediaLibrary(store)
        }}
    }}
}

@Composable fun Home(store:LocalStore){
    val memories=store.load("memories");val goals=store.load("goals");val tasks=store.load("tasks");val media=store.loadMedia()
    Column(Modifier.padding(22.dp)){Text("Rizo Life",style=MaterialTheme.typography.headlineLarge,fontWeight=FontWeight.Bold);Text("مساحتك الشخصية",color=Color.Gray)
        Spacer(Modifier.height(22.dp));Card(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp)){Text("👋 مرحبًا",style=MaterialTheme.typography.titleLarge);Text("بياناتك الشخصية محفوظة محليًا على جهازك.")}}
        Spacer(Modifier.height(14.dp));Text("نظرة سريعة",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Stat("🎯",goals.size.toString(),"أهداف");Stat("✓",tasks.count{!it.done}.toString(),"مهام");Stat("🎬",media.size.toString(),"ترفيه");Stat("🧠",memories.size.toString(),"ذكريات")}
    }
}
@Composable fun Stat(a:String,b:String,c:String){Card(Modifier.weight(1f)){Column(Modifier.padding(8.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(a);Text(b,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);Text(c)}}}

@Composable fun PersistentSection(title:String,desc:String,key:String,store:LocalStore){
    var text by remember{mutableStateOf("")};var list by remember{mutableStateOf(store.load(key))}
    Column(Modifier.padding(22.dp)){Text(title,style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Text(desc,color=Color.Gray);Spacer(Modifier.height(16.dp))
        OutlinedTextField(text,{text=it},Modifier.fillMaxWidth(),label={Text("أضف عنصرًا جديدًا")});Spacer(Modifier.height(8.dp));Button({if(text.isNotBlank()){list=list+Item(text);store.save(key,list);text=""}},Modifier.fillMaxWidth()){Text("إضافة")}
        Spacer(Modifier.height(16.dp));LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){itemsIndexed(list){index,x->Card(Modifier.fillMaxWidth()){Row(Modifier.fillMaxWidth().padding(16.dp)){Text(x.title,Modifier.weight(1f));TextButton({list=list.filterIndexed{i,_->i!=index};store.save(key,list)}){Text("حذف")}}}}}
    }
}

@Composable fun PersistentTasks(store:LocalStore){
    var text by remember{mutableStateOf("")};var list by remember{mutableStateOf(store.load("tasks"))}
    Column(Modifier.padding(22.dp)){Text("✓ مهامي",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));OutlinedTextField(text,{text=it},Modifier.fillMaxWidth(),label={Text("مهمة جديدة")});Spacer(Modifier.height(8.dp))
        Button({if(text.isNotBlank()){list=list+Item(text);store.save("tasks",list);text=""}},Modifier.fillMaxWidth()){Text("إضافة مهمة")};Spacer(Modifier.height(14.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){itemsIndexed(list){index,x->Card(Modifier.fillMaxWidth()){Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically){Checkbox(x.done,{list=list.toMutableList().also{it[index]=x.copy(done=!x.done)};store.save("tasks",list)});Text(x.title,Modifier.weight(1f));TextButton({list=list.filterIndexed{i,_->i!=index};store.save("tasks",list)}){Text("حذف")}}}}}
    }
}

private suspend fun httpGet(url:String, headers:Map<String,String> = emptyMap()):JSONObject = withContext(Dispatchers.IO){
    val c=URL(url).openConnection() as HttpURLConnection;c.requestMethod="GET";c.connectTimeout=12000;c.readTimeout=12000
    headers.forEach{(k,v)->c.setRequestProperty(k,v)}
    val code=c.responseCode;val stream=if(code in 200..299)c.inputStream else c.errorStream
    val body=stream?.bufferedReader()?.use{it.readText()} ?: "{}";c.disconnect()
    if(code !in 200..299) throw Exception("HTTP $code")
    JSONObject(body)
}

private suspend fun enrichTMDB(title:String,type:String,key:String):EnrichedMedia{
    if(key.isBlank()) return EnrichedMedia()
    val kind=if(type=="مسلسل")"tv" else "movie"
    val q=URLEncoder.encode(title,"UTF-8")
    val search=httpGet("https://api.themoviedb.org/3/search/$kind?query=$q&language=ar-SA&page=1",mapOf("Authorization" to "Bearer $key","accept" to "application/json"))
    val r=search.optJSONArray("results")?.optJSONObject(0) ?: return EnrichedMedia()
    val poster=r.optString("poster_path").takeIf{it.isNotBlank()}?.let{"https://image.tmdb.org/t/p/w500$it"} ?: ""
    val year=(if(type=="مسلسل")r.optString("first_air_date") else r.optString("release_date")).take(4)
    val genres=r.optJSONArray("genre_ids")?.let{a->(0 until a.length()).joinToString(", "){a.optInt(it).toString()}} ?: ""
    val desc=r.optString("overview")
    return EnrichedMedia(poster,year,genres,desc)
}

private suspend fun enrichRAWG(title:String,key:String):EnrichedMedia{
    if(key.isBlank()) return EnrichedMedia()
    val q=URLEncoder.encode(title,"UTF-8")
    val search=httpGet("https://api.rawg.io/api/games?key=$key&search=$q&search_precise=true&page_size=1")
    val r=search.optJSONArray("results")?.optJSONObject(0) ?: return EnrichedMedia()
    val id=r.optInt("id",0);var desc=""
    if(id>0){try{desc=httpGet("https://api.rawg.io/api/games/$id?key=$key").optString("description_raw")}catch(_:Exception){}}
    val genres=r.optJSONArray("genres")?.let{a->(0 until a.length()).joinToString(", "){a.optJSONObject(it)?.optString("name").orEmpty()}.trim().trimEnd(',')}} ?: ""
    return EnrichedMedia(r.optString("background_image"),r.optString("released").take(4),genres,desc)
}

private suspend fun geminiSummary(title:String,type:String,meta:EnrichedMedia,key:String):String = withContext(Dispatchers.IO){
    if(key.isBlank()) return@withContext ""
    val prompt="أنت مساعد لمكتبة ترفيه شخصية. أعطني بالعربية فقرة قصيرة جدًا (2-3 جمل) عن $type «$title». لا تخترع أحداثًا. استخدم هذه البيانات إن وجدت: السنة=${meta.year}; الأنواع=${meta.genres}; الوصف=${meta.description.take(700)}. أضف في النهاية سطرًا يبدأ بـ 'لماذا قد يعجبني:' ويكون عامًا وغير متحيز."
    val body=JSONObject().apply{put("contents",JSONArray().put(JSONObject().apply{put("parts",JSONArray().put(JSONObject().put("text",prompt)))}));put("generationConfig",JSONObject().put("maxOutputTokens",300))}
    val c=URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent").openConnection() as HttpURLConnection
    c.requestMethod="POST";c.doOutput=true;c.connectTimeout=15000;c.readTimeout=20000;c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("x-goog-api-key",key)
    c.outputStream.use{it.write(body.toString().toByteArray())};val code=c.responseCode;val stream=if(code in 200..299)c.inputStream else c.errorStream;val text=stream?.bufferedReader()?.use{it.readText()} ?: "{}";c.disconnect();if(code !in 200..299) throw Exception("Gemini HTTP $code")
    val root=JSONObject(text);root.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text").orEmpty()
}

@Composable fun MediaLibrary(store:LocalStore){
    var title by remember{mutableStateOf("")};var type by remember{mutableStateOf("فيلم")};var rating by remember{mutableIntStateOf(0)};var note by remember{mutableStateOf("")};var list by remember{mutableStateOf(store.loadMedia())}
    var busy by remember{mutableStateOf(false)};var message by remember{mutableStateOf("")};var showSettings by remember{mutableStateOf(false)};val scope=rememberCoroutineScope()
    Column(Modifier.padding(18.dp)){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("🎬 مكتبتي الترفيهية",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Text("أفلام • مسلسلات • ألعاب",color=Color.Gray)};TextButton({showSettings=true}){Text("⚙ الإعدادات")}}
        Spacer(Modifier.height(12.dp));OutlinedTextField(title,{title=it},Modifier.fillMaxWidth(),label={Text("اسم العمل")});Spacer(Modifier.height(7.dp));Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("فيلم","مسلسل","لعبة").forEach{t->FilterChip(selected=type==t,onClick={type=t},label={Text(t)})}}
        Spacer(Modifier.height(7.dp));OutlinedTextField(note,{note=it},Modifier.fillMaxWidth(),label={Text("ملاحظة اختيارية")});Spacer(Modifier.height(7.dp));Text("تقييمك: ${if(rating==0)"بدون تقييم" else "$rating/10"}");Slider(value=rating.toFloat(),onValueChange={rating=it.toInt()},valueRange=0f..10f,steps=9)
        Button(enabled=!busy,onClick={if(title.isNotBlank()){val t=title.trim();val typ=type;val r=rating;val n=note;busy=true;message="جارٍ جلب المعلومات…";scope.launch{try{
            val tmdb=store.get("tmdb_key");val rawg=store.get("rawg_key");val gemini=store.get("gemini_key")
            var meta=if(typ=="لعبة")enrichRAWG(t,rawg) else enrichTMDB(t,typ,tmdb);val ai=geminiSummary(t,typ,meta,gemini)
            val new=Media(t,typ,r,n,meta.posterUrl,meta.year,meta.genres,meta.description,ai);list=list+new;store.saveMedia(list);title="";note="";rating=0;message="تمت الإضافة والإثراء تلقائيًا ✨"
        }catch(e:Exception){val new=Media(t,typ,r,n);list=list+new;store.saveMedia(list);message="تم الحفظ، لكن تعذر الإثراء: ${e.message ?: "تحقق من المفاتيح والإنترنت"}"}finally{busy=false}}}},Modifier.fillMaxWidth()){Text(if(busy)"⏳ جارٍ الإثراء…" else "✨ إضافة + إثراء تلقائي")}
        if(message.isNotBlank()){Spacer(Modifier.height(8.dp));Text(message,color=MaterialTheme.colorScheme.primary)};Spacer(Modifier.height(14.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp)){itemsIndexed(list){index,m->Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(12.dp)){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.Top){if(m.posterUrl.isNotBlank())AsyncImage(model=m.posterUrl,contentDescription=null,modifier=Modifier.size(78.dp).padding(end=10.dp));Column(Modifier.weight(1f)){Row(Modifier.fillMaxWidth()){Text(m.title,Modifier.weight(1f),fontWeight=FontWeight.Bold);Text(m.type)};if(m.year.isNotBlank())Text(m.year,color=Color.Gray);if(m.genres.isNotBlank())Text(m.genres,color=Color.Gray);Text(if(m.rating>0)"⭐ ${m.rating}/10" else "لم يتم التقييم")}}
                    if(m.description.isNotBlank()){Spacer(Modifier.height(7.dp));Text(m.description,maxLines=5)};if(m.aiSummary.isNotBlank()){Spacer(Modifier.height(7.dp));Text("🤖 ${m.aiSummary}",color=MaterialTheme.colorScheme.primary)};if(m.note.isNotBlank())Text("📝 ${m.note}",color=Color.Gray);TextButton({list=list.filterIndexed{i,_->i!=index};store.saveMedia(list)}){Text("حذف")}
                }}}
        }
    }
    if(showSettings)ApiSettings(store,{showSettings=false})
}

@Composable fun ApiSettings(store:LocalStore,onClose:()->Unit){
    var tmdb by remember{mutableStateOf(store.get("tmdb_key"))};var rawg by remember{mutableStateOf(store.get("rawg_key"))};var gemini by remember{mutableStateOf(store.get("gemini_key"))}
    AlertDialog(onDismissRequest=onClose,title={Text("⚙ إعدادات الإثراء المجاني")},text={Column{Text("المفاتيح تُحفظ على جهازك فقط. لا تضع مفاتيحك داخل مشروع منشور للعامة.",color=Color.Gray);Spacer(Modifier.height(8.dp));OutlinedTextField(tmdb,{tmdb=it},label={Text("TMDB API Read Access Token")},singleLine=true);OutlinedTextField(rawg,{rawg=it},label={Text("RAWG API Key — للألعاب")},singleLine=true);OutlinedTextField(gemini,{gemini=it},label={Text("Gemini API Key — للذكاء الاصطناعي")},singleLine=true)}},confirmButton={Button({store.set("tmdb_key",tmdb.trim());store.set("rawg_key",rawg.trim());store.set("gemini_key",gemini.trim());onClose()}){Text("حفظ")}},dismissButton={TextButton(onClose){Text("إلغاء")}})
}
